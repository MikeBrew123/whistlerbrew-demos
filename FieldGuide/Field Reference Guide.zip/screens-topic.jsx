/* ── TOPIC PAGE ─────────────────────────────────────────────────────────────── */

/* Head Fire Intensity ladder — simple box diagram (P01 doctrine) */
function HFILadder({rungs}){
  return (
    <div style={{background:'var(--surface-2)',border:'1px solid var(--border)',borderRadius:16,
      padding:'15px 15px 16px',margin:'4px 0 2px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
        <span className="eyebrow">Head Fire Intensity → Defendability</span>
        <span style={{fontSize:10.5,color:'var(--text-3)',fontFamily:'var(--mono)'}}>flame height</span>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:7}}>
        {rungs.map(([label,action,color],i)=>(
          <div key={i} style={{display:'flex',alignItems:'center',gap:11}}>
            <div style={{width:74,flexShrink:0,textAlign:'right',fontSize:12,fontWeight:700,
              color:'var(--text)',lineHeight:1.1}}>{label}</div>
            <div style={{flex:1,height:30,borderRadius:8,background:color,opacity:.92,
              width:`${42+i*14}%`,display:'flex',alignItems:'center',paddingLeft:11,
              boxShadow:'inset 0 1px 0 rgba(255,255,255,.25)'}}>
              <span style={{fontSize:11.5,fontWeight:700,color:'rgba(0,0,0,.78)',lineHeight:1.05}}>{action}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InfographicSlot({label}){
  return (
    <div className="slot" style={{minHeight:128,marginTop:6}}>
      <IconLayers size={26}/>
      <div style={{fontSize:13.5,fontWeight:600,color:'var(--text-2)'}}>{label}</div>
      <div className="mono">infographic · drop final diagram here</div>
    </div>
  );
}

function DoctrineList({items,accent}){
  return (
    <ul className="dl" style={{'--accent':accent}}>
      {items.map(([lead,detail],i)=>(
        <li key={i}><Html s={lead}/>{detail?<> <span className="lead"><Html s={detail}/></span></>:null}</li>
      ))}
    </ul>
  );
}

function TopicScreen({code}){
  const {go,bookmarks,toggleBookmark}=useStore();
  const [side,setSide]=React.useState('qr');
  const b=bookletOf(code);
  const title=titleOf(code);
  const c=getContent(code,title);
  const marked=bookmarks.has(code);
  const hasInfo=HAS_INFOGRAPHIC.has(code);

  React.useEffect(()=>{ setSide('qr'); },[code]);

  return (
    <>
      <AppBar title={code} right={
        <button className="icon-btn" onClick={()=>toggleBookmark(code)} aria-label="Bookmark"
          style={marked?{color:'var(--amber)'}:null}>
          {marked?<IconBookmarkFill size={22}/>:<IconBookmark size={22}/>}
        </button>
      }/>
      <div className="scroll screen-anim" style={{paddingTop:0}}>
        {/* title block */}
        <div className="pad" style={{paddingTop:'calc(var(--safe-top) + 6px)',paddingBottom:14}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:9}}>
            <span className="code" style={{fontSize:13,fontWeight:700,color:b.accent,
              background:b.soft,padding:'4px 9px',borderRadius:8}}>{code}</span>
            <span style={{fontSize:12.5,color:'var(--text-2)',fontWeight:600}}>{b.name}</span>
            {c.sample && <Badge color="var(--text-2)" soft="var(--surface-2)">SAMPLE</Badge>}
          </div>
          <h1 style={{margin:0,fontSize:25,fontWeight:700,letterSpacing:'-.02em',lineHeight:1.12}}>{title}</h1>
        </div>

        {/* sticky segmented toggle */}
        <div style={{position:'sticky',top:'var(--safe-top)',zIndex:30,
          background:'linear-gradient(180deg,var(--bg) 78%,transparent)',padding:'4px 18px 12px'}}>
          <div className="seg">
            <button className={side==='qr'?'on':''} onClick={()=>setSide('qr')}>
              <IconLayers size={16}/> Quick Reference</button>
            <button className={side==='fd'?'on':''} onClick={()=>setSide('fd')}>
              <IconDoc size={16}/> Field Doctrine</button>
          </div>
        </div>

        <div className="pad" style={{paddingBottom:14}}>
          {side==='qr' ? (
            <div className="screen-anim" key="qr">
              <DoctrineList items={c.quickRef} accent={b.accent}/>
              {hasInfo && <div style={{marginTop:18}}><InfographicSlot label={`${title} — reference diagram`}/></div>}
            </div>
          ) : (
            <div className="screen-anim" key="fd">
              <DoctrineList items={c.doctrine} accent={b.accent}/>
              {c.hfi && <div style={{marginTop:16}}><HFILadder rungs={c.hfi}/></div>}
              {c.quote && (
                <blockquote style={{margin:'18px 0 2px',padding:'15px 16px',background:b.soft,
                  borderRadius:14,borderLeft:`3px solid ${b.accent}`}}>
                  <div style={{fontSize:15.5,lineHeight:1.45,fontStyle:'italic',color:'var(--text)'}}>“{c.quote[0]}”</div>
                  <div style={{marginTop:8,fontSize:12.5,fontWeight:700,color:b.accent,
                    fontFamily:'var(--mono)'}}>— {c.quote[1]}</div>
                </blockquote>
              )}
              {hasInfo && !c.hfi && <div style={{marginTop:18}}><InfographicSlot label={`${title} — doctrine diagram`}/></div>}
            </div>
          )}

          {/* cross-link footer */}
          <button onClick={()=>go('booklet',{id:b.id})}
            style={{marginTop:24,width:'100%',display:'flex',alignItems:'center',justifyContent:'space-between',
              padding:'13px 15px',background:'var(--surface)',border:'1px solid var(--border)',
              borderRadius:14,textAlign:'left'}}>
            <span style={{fontSize:13.5,color:'var(--text-2)'}}>More in <b style={{color:b.accent}}>{b.name}</b></span>
            <IconChevR size={18} style={{color:'var(--text-3)'}}/>
          </button>
        </div>
      </div>
    </>
  );
}

Object.assign(window,{ HFILadder, InfographicSlot, DoctrineList, TopicScreen });
