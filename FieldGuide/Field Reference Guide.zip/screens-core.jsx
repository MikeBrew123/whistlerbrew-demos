/* ── CORE SCREENS: Home · Browse · Booklet · Topic ──────────────────────────── */
const Html=({s,style,cls})=><span className={cls} style={style} dangerouslySetInnerHTML={{__html:s}}/>;

/* ---- HOME ---- */
function HomeScreen(){
  const {go,recents}=useStore();
  return (
    <>
      <AppBar title="BCWS Pocket Guide" right={
        <div className="icon-btn" style={{color:'var(--o)'}} onClick={()=>go('settings')}><IconOffline size={22}/></div>
      }/>
      <div className="scroll screen-anim">
        <div className="pad">
          <div style={{marginBottom:16}} onClick={()=>go('search')}>
            <SearchField value="" placeholder="Search all topics & CE"/>
          </div>

          <div className="eyebrow" style={{marginBottom:10}}>Booklets</div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {BOOKLETS.map(b=>(
              <BookletCard key={b.id} b={b} onClick={()=>go('booklet',{id:b.id})}/>
            ))}
          </div>

          {/* CE entry */}
          <div className="eyebrow" style={{margin:'22px 0 10px'}}>Continuing Education</div>
          <button className="card" onClick={()=>go('ce')}
            style={{width:'100%',textAlign:'left',padding:0,overflow:'hidden',display:'flex',alignItems:'stretch'}}>
            <div style={{width:6,background:'var(--ce)'}}/>
            <div style={{flex:1,padding:'16px 16px 16px 15px',display:'flex',alignItems:'center',gap:14}}>
              <div style={{width:46,height:46,borderRadius:13,background:'var(--ce-soft)',color:'var(--ce)',
                display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <IconPlay size={20}/>
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:17.5,fontWeight:700,letterSpacing:'-.01em'}}>CE Sessions</div>
                <div style={{fontSize:13,color:'var(--text-2)',marginTop:1}}>Video summaries · transcripts · takeaways</div>
              </div>
              <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:2}}>
                <span className="code" style={{fontSize:13,fontWeight:700,color:'var(--ce)'}}>18</span>
                <span style={{fontSize:10,color:'var(--text-3)',fontFamily:'var(--mono)'}}>videos</span>
              </div>
            </div>
          </button>

          {/* Recently viewed */}
          {recents.length>0 && <>
            <div className="eyebrow" style={{margin:'22px 0 10px'}}>Recently viewed</div>
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {recents.slice(0,4).map(code=>{
                const b=bookletOf(code);
                return (
                  <button key={code} className="card" onClick={()=>go('topic',{code})}
                    style={{display:'flex',alignItems:'center',gap:12,padding:'12px 14px',textAlign:'left',width:'100%'}}>
                    <span className="code" style={{fontSize:12.5,fontWeight:700,color:b.accent,
                      background:b.soft,padding:'3px 8px',borderRadius:7,flexShrink:0}}>{code}</span>
                    <span style={{flex:1,fontSize:14.5,fontWeight:600,overflow:'hidden',
                      textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{titleOf(code)}</span>
                    <IconChevR size={18} style={{color:'var(--text-3)'}}/>
                  </button>
                );
              })}
            </div>
          </>}
          <div style={{height:8}}/>
        </div>
      </div>
    </>
  );
}

/* ---- BROWSE (Index tab) ---- */
function BrowseScreen(){
  const {go}=useStore();
  return (
    <>
      <AppBar title="Index"/>
      <div className="scroll screen-anim">
        <div className="pad">
          <div className="eyebrow" style={{margin:'2px 0 10px'}}>4 booklets · 51 topics</div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {BOOKLETS.map(b=><BookletCard key={b.id} b={b} onClick={()=>go('booklet',{id:b.id})}/>)}
          </div>
          <div className="eyebrow" style={{margin:'22px 0 10px'}}>Continuing Education</div>
          <button className="card" onClick={()=>go('ce')}
            style={{width:'100%',textAlign:'left',padding:0,overflow:'hidden',display:'flex',alignItems:'stretch'}}>
            <div style={{width:6,background:'var(--ce)'}}/>
            <div style={{flex:1,padding:'16px',display:'flex',alignItems:'center',gap:14}}>
              <div style={{width:46,height:46,borderRadius:13,background:'var(--ce-soft)',color:'var(--ce)',
                display:'flex',alignItems:'center',justifyContent:'center'}}><IconPlay size={20}/></div>
              <div style={{flex:1}}>
                <div style={{fontSize:17.5,fontWeight:700}}>CE Sessions</div>
                <div style={{fontSize:13,color:'var(--text-2)'}}>18 video summaries</div>
              </div>
              <IconChevR size={20} style={{color:'var(--text-3)'}}/>
            </div>
          </button>
        </div>
      </div>
    </>
  );
}

/* ---- BOOKLET INDEX (topic grid) ---- */
function BookletScreen({id}){
  const {go,bookmarks}=useStore();
  const b=BOOKLETS.find(x=>x.id===id);
  const topics=TOPICS[id];
  return (
    <>
      <AppBar title={b.name}/>
      <div className="scroll screen-anim">
        {/* accent header band */}
        <div className="pad" style={{paddingTop:4,paddingBottom:14}}>
          <div style={{display:'flex',alignItems:'center',gap:13}}>
            <div style={{width:52,height:52,borderRadius:15,background:b.soft,color:b.accent,
              display:'flex',alignItems:'center',justifyContent:'center'}}>
              <span className="code" style={{fontSize:23,fontWeight:700}}>{b.id}</span>
            </div>
            <div>
              <div style={{fontSize:22,fontWeight:700,letterSpacing:'-.02em'}}>{b.name}</div>
              <div style={{fontSize:13,color:'var(--text-2)'}}>{topics.length} topics · {b.sub}</div>
            </div>
          </div>
        </div>
        <div className="pad" style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
          {topics.map(([code,title])=>(
            <TopicCard key={code} code={code} title={title} marked={bookmarks.has(code)}
              onClick={()=>go('topic',{code})}/>
          ))}
        </div>
        <div style={{height:10}}/>
      </div>
    </>
  );
}

Object.assign(window,{ Html, HomeScreen, BrowseScreen, BookletScreen });
