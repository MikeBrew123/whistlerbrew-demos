/* ── CE · SEARCH · SAVED · SETTINGS ─────────────────────────────────────────── */

/* ---- CE INDEX ---- */
function CEScreen(){
  const {go}=useStore();
  return (
    <>
      <AppBar title="CE Sessions"/>
      <div className="scroll screen-anim">
        <div className="pad" style={{paddingTop:2}}>
          <div className="eyebrow" style={{marginBottom:12}}>18 sessions · summaries & transcripts</div>
          <div style={{display:'flex',flexDirection:'column',gap:9}}>
            {CE_SESSIONS.map(item=>{
              const [n,title,date]=item;
              return (
                <button key={n} className="card" onClick={()=>go('ceDetail',{n})}
                  style={{display:'flex',gap:13,padding:'12px 13px',textAlign:'left',width:'100%',alignItems:'center'}}>
                  <div style={{width:54,height:54,borderRadius:12,background:'var(--ce-soft)',flexShrink:0,
                    display:'flex',alignItems:'center',justifyContent:'center',position:'relative',
                    border:'1px solid rgba(192,132,252,.25)'}}>
                    <IconPlay size={19} style={{color:'var(--ce)'}}/>
                    <span className="code" style={{position:'absolute',top:4,left:6,fontSize:10,
                      fontWeight:700,color:'var(--ce)',opacity:.7}}>{String(n).padStart(2,'0')}</span>
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:14.5,fontWeight:600,lineHeight:1.28,letterSpacing:'-.01em'}}>{title}</div>
                    <div style={{display:'flex',alignItems:'center',gap:10,marginTop:5,color:'var(--text-3)',
                      fontSize:11.5,fontFamily:'var(--mono)'}}>
                      {date && <span style={{whiteSpace:'nowrap'}}>{date}</span>}
                      <span style={{display:'flex',alignItems:'center',gap:4}}><IconDoc size={12}/>transcript</span>
                    </div>
                  </div>
                  <IconChevR size={18} style={{color:'var(--text-3)',flexShrink:0}}/>
                </button>
              );
            })}
          </div>
          <div style={{height:8}}/>
        </div>
      </div>
    </>
  );
}

/* ---- CE DETAIL ---- */
function CEDetailScreen({n}){
  const item=CE_SESSIONS.find(c=>c[0]===n);
  const d=ceDetail(item);
  return (
    <>
      <AppBar title={`Session ${String(n).padStart(2,'0')}`}/>
      <div className="scroll screen-anim">
        <div className="pad">
          {/* video poster */}
          <div className="slot" style={{minHeight:170,marginTop:2,position:'relative',
            background:'radial-gradient(120% 120% at 30% 20%,#241c33,#171717)'}}>
            <div style={{width:56,height:56,borderRadius:'50%',background:'rgba(192,132,252,.18)',
              border:'1px solid rgba(192,132,252,.4)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <IconPlay size={24} style={{color:'var(--ce)'}}/>
            </div>
            <div className="mono" style={{marginTop:2}}>video summary · {d.runtime} min</div>
          </div>

          <div style={{display:'flex',alignItems:'center',gap:8,margin:'16px 0 7px'}}>
            <span className="code" style={{fontSize:12,fontWeight:700,color:'var(--ce)',
              background:'var(--ce-soft)',padding:'3px 8px',borderRadius:7}}>CE {String(n).padStart(2,'0')}</span>
            {d.date && <span style={{fontSize:12,color:'var(--text-2)',fontFamily:'var(--mono)'}}>{d.date}</span>}
            <Badge color="var(--text-2)" soft="var(--surface-2)">SAMPLE</Badge>
          </div>
          <h1 style={{margin:'0 0 16px',fontSize:23,fontWeight:700,letterSpacing:'-.02em',lineHeight:1.15}}>{d.title}</h1>

          <div className="eyebrow" style={{marginBottom:8}}>Summary</div>
          <p style={{margin:0,fontSize:15,lineHeight:1.5,color:'var(--text)'}}>{d.summary}</p>

          <div className="eyebrow" style={{margin:'22px 0 10px'}}>Key takeaways</div>
          <ul className="dl" style={{'--accent':'var(--ce)'}}>
            {d.takeaways.map((t,i)=><li key={i}>{t}</li>)}
          </ul>

          <div className="eyebrow" style={{margin:'22px 0 10px'}}>Transcript</div>
          <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:14,
            padding:'14px 15px',display:'flex',flexDirection:'column',gap:11}}>
            {d.transcript.map((t,i)=>(
              <div key={i} style={{fontSize:13.5,lineHeight:1.5,color:'var(--text-2)',fontFamily:'var(--mono)'}}>{t}</div>
            ))}
          </div>
          <div style={{height:8}}/>
        </div>
      </div>
    </>
  );
}

/* ---- SEARCH ---- */
function SearchScreen(){
  const {go}=useStore();
  const [q,setQ]=React.useState('');
  const ql=q.trim().toLowerCase();
  const topicHits=[];
  if(ql) for(const b of BOOKLETS) for(const [code,title] of TOPICS[b.id])
    if(code.toLowerCase().includes(ql)||title.toLowerCase().includes(ql)) topicHits.push([code,title]);
  const ceHits= ql? CE_SESSIONS.filter(c=>c[1].toLowerCase().includes(ql)) : [];

  return (
    <>
      <AppBar title="Search"/>
      <div className="scroll screen-anim">
        <div className="pad">
          <SearchField value={q} onChange={setQ} autoFocus/>
          {!ql && (
            <div style={{marginTop:18}}>
              <div className="eyebrow" style={{marginBottom:10}}>Jump to booklet</div>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {BOOKLETS.map(b=>(
                  <button key={b.id} onClick={()=>go('booklet',{id:b.id})}
                    style={{display:'flex',alignItems:'center',gap:7,padding:'9px 13px',borderRadius:11,
                      background:b.soft,color:b.accent,fontWeight:700,fontSize:13.5}}>
                    <span className="code">{b.id}</span>{b.name}</button>
                ))}
              </div>
            </div>
          )}
          {ql && (
            <div style={{marginTop:16}}>
              {topicHits.length>0 && <>
                <div className="eyebrow" style={{marginBottom:10}}>Topics · {topicHits.length}</div>
                <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:18}}>
                  {topicHits.map(([code,title])=>{
                    const b=bookletOf(code);
                    return (
                      <button key={code} className="card" onClick={()=>go('topic',{code})}
                        style={{display:'flex',alignItems:'center',gap:12,padding:'12px 14px',textAlign:'left',width:'100%'}}>
                        <span className="code" style={{fontSize:12.5,fontWeight:700,color:b.accent,
                          background:b.soft,padding:'3px 8px',borderRadius:7,flexShrink:0}}>{code}</span>
                        <span style={{flex:1,fontSize:14.5,fontWeight:600}}>{title}</span>
                        <IconChevR size={18} style={{color:'var(--text-3)'}}/>
                      </button>
                    );
                  })}
                </div>
              </>}
              {ceHits.length>0 && <>
                <div className="eyebrow" style={{marginBottom:10}}>CE Sessions · {ceHits.length}</div>
                <div style={{display:'flex',flexDirection:'column',gap:8}}>
                  {ceHits.map(c=>(
                    <button key={c[0]} className="card" onClick={()=>go('ceDetail',{n:c[0]})}
                      style={{display:'flex',alignItems:'center',gap:12,padding:'12px 14px',textAlign:'left',width:'100%'}}>
                      <IconPlay size={16} style={{color:'var(--ce)',flexShrink:0}}/>
                      <span style={{flex:1,fontSize:14.5,fontWeight:600}}>{c[1]}</span>
                      <IconChevR size={18} style={{color:'var(--text-3)'}}/>
                    </button>
                  ))}
                </div>
              </>}
              {topicHits.length===0 && ceHits.length===0 && (
                <div style={{textAlign:'center',color:'var(--text-3)',marginTop:40,fontSize:14.5}}>
                  No matches for “{q}”</div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ---- SAVED ---- */
function SavedScreen(){
  const {go,bookmarks}=useStore();
  const codes=[...bookmarks];
  return (
    <>
      <AppBar title="Saved"/>
      <div className="scroll screen-anim">
        <div className="pad">
          {codes.length===0 ? (
            <div style={{textAlign:'center',marginTop:80,color:'var(--text-3)'}}>
              <IconBookmark size={38} style={{color:'var(--text-3)'}}/>
              <div style={{fontSize:16,fontWeight:600,color:'var(--text-2)',marginTop:12}}>No saved topics yet</div>
              <div style={{fontSize:13.5,marginTop:6,lineHeight:1.5,maxWidth:240,margin:'6px auto 0'}}>
                Tap the bookmark on any topic to pin it here for the incident.</div>
            </div>
          ) : (
            <>
              <div className="eyebrow" style={{margin:'2px 0 10px'}}>{codes.length} pinned for this incident</div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                {codes.map(code=>(
                  <TopicCard key={code} code={code} title={titleOf(code)} marked
                    onClick={()=>go('topic',{code})}/>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

/* ---- SETTINGS ---- */
function Row({children,onClick,last}){
  return (
    <button onClick={onClick} disabled={!onClick}
      style={{display:'flex',alignItems:'center',gap:13,width:'100%',textAlign:'left',
        padding:'14px 15px',borderBottom:last?'none':'1px solid var(--border)',
        background:'none',cursor:onClick?'pointer':'default'}}>{children}</button>
  );
}
function SettingsScreen(){
  const {textScale,setTextScale}=useStore();
  return (
    <>
      <AppBar title="Settings"/>
      <div className="scroll screen-anim">
        <div className="pad">
          {/* offline status */}
          <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:16,
            padding:'15px 16px',display:'flex',alignItems:'center',gap:13,marginBottom:18}}>
            <div style={{width:42,height:42,borderRadius:12,background:'var(--o-soft)',color:'var(--o)',
              display:'flex',alignItems:'center',justifyContent:'center'}}><IconOffline size={22}/></div>
            <div style={{flex:1}}>
              <div style={{fontSize:15.5,fontWeight:700}}>Offline ready</div>
              <div style={{fontSize:13,color:'var(--text-2)'}}>All booklets & CE cached on device</div>
            </div>
            <span className="badge" style={{color:'var(--o)',background:'var(--o-soft)'}}>PWA</span>
          </div>

          <div className="eyebrow" style={{margin:'0 0 9px 3px'}}>Display</div>
          <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:16,padding:'15px 16px'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
              <IconType size={19} style={{color:'var(--text-2)'}}/>
              <span style={{fontSize:15,fontWeight:600,flex:1}}>Text size</span>
              <span className="code" style={{fontSize:12.5,color:'var(--amber)'}}>{Math.round(textScale*100)}%</span>
            </div>
            <input type="range" min="0.9" max="1.3" step="0.05" value={textScale}
              onChange={e=>setTextScale(parseFloat(e.target.value))}
              style={{width:'100%',accentColor:'var(--amber)'}}/>
            <div style={{display:'flex',justifyContent:'space-between',marginTop:4,
              fontSize:11,color:'var(--text-3)',fontFamily:'var(--mono)'}}><span>A</span><span style={{fontSize:15}}>A</span></div>
          </div>

          <div className="eyebrow" style={{margin:'20px 0 9px 3px'}}>About</div>
          <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:16,overflow:'hidden'}}>
            <Row><span style={{flex:1,fontSize:15}}>Version</span><span style={{color:'var(--text-3)',fontFamily:'var(--mono)',fontSize:13}}>2026.1</span></Row>
            <Row><span style={{flex:1,fontSize:15}}>Content set</span><span style={{color:'var(--text-3)',fontFamily:'var(--mono)',fontSize:13}}>BCWS SP</span></Row>
            <Row last><span style={{flex:1,fontSize:15}}>Theme</span><span style={{color:'var(--amber)',fontFamily:'var(--mono)',fontSize:13}}>Dark · field</span></Row>
          </div>
          <div style={{textAlign:'center',color:'var(--text-3)',fontSize:11.5,marginTop:20,
            fontFamily:'var(--mono)',lineHeight:1.6}}>
            BCWS Structure Protection Pocket Guide<br/>whistlerBrew.com/projects/pocket-guide</div>
        </div>
      </div>
    </>
  );
}

Object.assign(window,{ CEScreen, CEDetailScreen, SearchScreen, SavedScreen, SettingsScreen });
