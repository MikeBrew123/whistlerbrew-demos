/* ── ICONS (simple stroke geometry) ─────────────────────────────────────────── */
function Ic({d,size=24,sw=1.8,fill='none',children,style}){
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
      stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round"
      style={style}>{d?<path d={d}/>:children}</svg>
  );
}

const IconHome   = p=><Ic {...p}><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h14V9.5"/></Ic>;
const IconGrid   = p=><Ic {...p}><rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/></Ic>;
const IconSearch = p=><Ic {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Ic>;
const IconBookmark = p=><Ic {...p}><path d="M6 3.5h12v17l-6-4.2L6 20.5z"/></Ic>;
const IconBookmarkFill = p=><Ic {...p} fill="currentColor" sw="0"><path d="M6 3.5h12v17l-6-4.2L6 20.5z"/></Ic>;
const IconGear   = p=><Ic {...p}><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v2.4M12 19.1v2.4M21.5 12h-2.4M4.9 12H2.5M18.7 5.3l-1.7 1.7M7 17l-1.7 1.7M18.7 18.7 17 17M7 7 5.3 5.3"/></Ic>;
const IconChevR  = p=><Ic {...p} sw="2.2"><path d="m9 5 7 7-7 7"/></Ic>;
const IconChevL  = p=><Ic {...p} sw="2.2"><path d="m15 5-7 7 7 7"/></Ic>;
const IconPlay   = p=><Ic {...p} fill="currentColor" sw="0"><path d="M7 4.5v15l13-7.5z"/></Ic>;
const IconClock  = p=><Ic {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5.2l3.3 2"/></Ic>;
const IconDoc    = p=><Ic {...p}><path d="M6 2.5h8l4 4V21.5H6z"/><path d="M14 2.5v4h4"/><path d="M9 12h6M9 15.5h6M9 8.5h2"/></Ic>;
const IconClock2 = p=><Ic {...p}><path d="M12 8v4.5M12 12.5 15 14"/><circle cx="12" cy="12" r="9"/></Ic>;
const IconX      = p=><Ic {...p} sw="2"><path d="M6 6l12 12M18 6 6 18"/></Ic>;
const IconOffline= p=><Ic {...p}><path d="M4 7c4.5-3.5 11.5-3.5 16 0"/><path d="M7 11c2.8-2.2 7.2-2.2 10 0"/><path d="M10 15c1.2-1 2.8-1 4 0"/><circle cx="12" cy="18.5" r="1" fill="currentColor" stroke="none"/></Ic>;
const IconLayers = p=><Ic {...p}><path d="M12 3 3 8l9 5 9-5z"/><path d="m3 13 9 5 9-5M3 16l9 5 9-5" opacity=".5"/></Ic>;
const IconArrow  = p=><Ic {...p} sw="2"><path d="M5 12h13M13 6l6 6-6 6"/></Ic>;
const IconType   = p=><Ic {...p}><path d="M5 6h14M9 6v13M12 11h7M15 11v8"/></Ic>;

Object.assign(window,{ Ic, IconHome, IconGrid, IconSearch, IconBookmark, IconBookmarkFill,
  IconGear, IconChevR, IconChevL, IconPlay, IconClock, IconDoc, IconClock2, IconX,
  IconOffline, IconLayers, IconArrow, IconType });
