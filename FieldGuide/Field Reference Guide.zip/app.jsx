/* ── APP: store, router, mount ──────────────────────────────────────────────── */
const LS={
  get:(k,d)=>{ try{const v=localStorage.getItem('bcws_'+k);return v?JSON.parse(v):d;}catch(e){return d;} },
  set:(k,v)=>{ try{localStorage.setItem('bcws_'+k,JSON.stringify(v));}catch(e){} },
};

function App(){
  const [stack,setStack]=React.useState([{screen:'home',params:{}}]);
  const [bookmarks,setBookmarks]=React.useState(()=>new Set(LS.get('bookmarks',[])));
  const [recents,setRecents]=React.useState(()=>LS.get('recents',[]));
  const [textScale,setTextScaleState]=React.useState(()=>LS.get('textScale',1));
  const scrollRef=React.useRef(null);

  const top=stack[stack.length-1];

  // tab roots reset the stack; drill-downs push
  const ROOT=new Set(['home','browse','search','saved','settings']);
  const go=(screen,params={})=>{
    setStack(s=>{
      if(ROOT.has(screen)) return [{screen,params}];
      return [...s,{screen,params}];
    });
  };
  const back=()=>setStack(s=> s.length>1? s.slice(0,-1) : s);

  // record recents when viewing a topic
  React.useEffect(()=>{
    if(top.screen==='topic'){
      const code=top.params.code;
      setRecents(r=>{ const nx=[code,...r.filter(c=>c!==code)].slice(0,8); LS.set('recents',nx); return nx; });
    }
    // scroll content to top on screen change
    if(scrollRef.current){ const sc=scrollRef.current.querySelector('.scroll'); if(sc) sc.scrollTop=0; }
  },[top.screen,top.params.code,top.params.id,top.params.n]);

  const toggleBookmark=(code)=>setBookmarks(prev=>{
    const nx=new Set(prev); nx.has(code)?nx.delete(code):nx.add(code);
    LS.set('bookmarks',[...nx]); return nx;
  });
  const setTextScale=(v)=>{ setTextScaleState(v); LS.set('textScale',v);
    document.documentElement.style.setProperty('--text-scale',v); };

  React.useEffect(()=>{ document.documentElement.style.setProperty('--text-scale',textScale); },[]);

  const store={ screen:top.screen, params:top.params, canBack:stack.length>1, go, back,
    bookmarks, toggleBookmark, recents, textScale, setTextScale };

  const render=()=>{
    const p=top.params;
    switch(top.screen){
      case 'home':     return <HomeScreen/>;
      case 'browse':   return <BrowseScreen/>;
      case 'booklet':  return <BookletScreen id={p.id}/>;
      case 'topic':    return <TopicScreen code={p.code}/>;
      case 'ce':       return <CEScreen/>;
      case 'ceDetail': return <CEDetailScreen n={p.n}/>;
      case 'search':   return <SearchScreen/>;
      case 'saved':    return <SavedScreen/>;
      case 'settings': return <SettingsScreen/>;
      default:         return <HomeScreen/>;
    }
  };

  return (
    <Store.Provider value={store}>
      <div className="app" ref={scrollRef} style={{fontSize:`calc(16px * ${textScale})`}}>
        {render()}
        <TabBar/>
      </div>
    </Store.Provider>
  );
}

function Root(){
  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',
      background:'#0a0a0a',padding:'24px 0'}}>
      <IOSDevice dark>
        <App/>
      </IOSDevice>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>);
