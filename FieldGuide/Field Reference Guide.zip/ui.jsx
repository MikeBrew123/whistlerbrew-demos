/* ── SHARED UI ───────────────────────────────────────────────────────────── */
const Store = React.createContext(null);
window.Store = Store;
const useStore = ()=>React.useContext(Store);

/* Top app bar — derives back navigation from the store */
const ROOTS=new Set(['home','browse','search','saved','settings']);
function AppBar({title,right}){
  const {screen,canBack,back}=useStore();
  const showBack=!ROOTS.has(screen)&&canBack;
  return (
    <div className="appbar">
      <div className="appbar-row">
        {showBack
          ? <button className="icon-btn" onClick={back} aria-label="Back"><IconChevL size={24}/></button>
          : <div style={{width:6}}/>}
        <div className="appbar-title" style={showBack?null:{paddingLeft:8}}>{title}</div>
        {right || <div style={{width:40}}/>}
      </div>
    </div>
  );
}

/* Bottom tab bar */
function TabBar(){
  const {screen,go}=useStore();
  const tabs=[
    ['home','Home',IconHome],
    ['browse','Index',IconGrid],
    ['search','Search',IconSearch],
    ['saved','Saved',IconBookmark],
    ['settings','Settings',IconGear],
  ];
  const activeFor=s=>{
    if(['home'].includes(screen)) return 'home';
    if(['browse','booklet','topic','ce','ceDetail'].includes(screen)) return 'browse';
    if(screen==='search') return 'search';
    if(screen==='saved') return 'saved';
    if(screen==='settings') return 'settings';
    return screen;
  };
  const cur=activeFor(screen);
  return (
    <nav className="tabbar">
      {tabs.map(([id,label,I])=>(
        <button key={id} className={'tab'+(cur===id?' active':'')} onClick={()=>go(id)}>
          <I size={23} sw={cur===id?2:1.8}/>
          <span className="tab-label">{label}</span>
        </button>
      ))}
    </nav>
  );
}

/* Booklet block — stacked, thumb-friendly */
function BookletCard({b,onClick}){
  const count=TOPICS[b.id].length;
  return (
    <button className="card" onClick={onClick}
      style={{display:'flex',alignItems:'stretch',gap:0,padding:0,overflow:'hidden',
        width:'100%',textAlign:'left'}}>
      <div style={{width:6,background:b.accent,flexShrink:0}}/>
      <div style={{flex:1,padding:'16px 16px 16px 15px',display:'flex',alignItems:'center',gap:14}}>
        <div style={{width:46,height:46,borderRadius:13,background:b.soft,color:b.accent,
          display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
          <span className="code" style={{fontSize:20,fontWeight:700}}>{b.id}</span>
        </div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:17.5,fontWeight:700,letterSpacing:'-.01em'}}>{b.name}</div>
          <div style={{fontSize:13,color:'var(--text-2)',marginTop:1,overflow:'hidden',
            textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{b.sub}</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:2,flexShrink:0}}>
          <span className="code" style={{fontSize:13,fontWeight:700,color:b.accent}}>{count}</span>
          <span style={{fontSize:10,color:'var(--text-3)',fontFamily:'var(--mono)'}}>topics</span>
        </div>
      </div>
    </button>
  );
}

/* Compact topic card for grids */
function TopicCard({code,title,onClick,marked}){
  const b=bookletOf(code);
  return (
    <button className="card" onClick={onClick}
      style={{padding:'13px 13px 14px',textAlign:'left',display:'flex',flexDirection:'column',
        gap:8,minHeight:96,position:'relative'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <span className="code" style={{fontSize:13,fontWeight:700,color:b.accent,
          background:b.soft,padding:'3px 8px',borderRadius:7}}>{code}</span>
        {marked && <IconBookmarkFill size={15} style={{color:'var(--amber)'}}/>}
      </div>
      <div style={{fontSize:14.5,fontWeight:600,lineHeight:1.28,letterSpacing:'-.01em'}}>{title}</div>
    </button>
  );
}

/* Search field (controlled) */
function SearchField({value,onChange,onFocus,autoFocus,placeholder='Search all topics & CE'}){
  const ref=React.useRef();
  React.useEffect(()=>{ if(autoFocus&&ref.current) ref.current.focus(); },[autoFocus]);
  return (
    <div className="searchfield">
      <IconSearch size={19}/>
      <input ref={ref} value={value} placeholder={placeholder} onFocus={onFocus}
        onChange={e=>onChange&&onChange(e.target.value)} readOnly={!onChange}/>
      {value
        ? <button className="icon-btn" style={{width:26,height:26}} onClick={()=>onChange('')}><IconX size={17}/></button>
        : null}
    </div>
  );
}

function Badge({children,color='var(--amber)',soft='var(--amber-soft)'}){
  return <span className="badge" style={{color,background:soft}}>{children}</span>;
}

Object.assign(window,{ useStore, AppBar, TabBar, BookletCard, TopicCard, SearchField, Badge });
