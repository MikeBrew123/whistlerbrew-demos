/* ── DATA ────────────────────────────────────────────────────────────────── */

const BOOKLETS = [
  { id:'P', name:'Protection', sub:'Sprinklers, pumps & water supply', accent:'var(--p)', soft:'var(--p-soft)', key:'p' },
  { id:'D', name:'Defence',    sub:'Tactics, task forces & integration', accent:'var(--d)', soft:'var(--d-soft)', key:'d' },
  { id:'S', name:'Safety',     sub:'LACES, watch-outs & survival',       accent:'var(--s)', soft:'var(--s-soft)', key:'s' },
  { id:'O', name:'Operations', sub:'Staging, tracking & documentation',  accent:'var(--o)', soft:'var(--o-soft)', key:'o' },
];

const TOPICS = {
  P:[
    ['P01','SPS Roles & Responsibilities'],['P02','SPU Type 1 Inventory'],['P03','SPU Type 2 Inventory'],
    ['P04','Property Size-Up / HIZ-SIZ'],['P05','Triage Overview'],['P06','Triage — Defensible Criteria'],
    ['P07','Triage — Flagging Standards'],['P08','Triage — Digital Tools (Survey123)'],['P09','Sprinklers — Choosing'],
    ['P10','Sprinklers — Setup & Coverage'],['P11','Sprinklers — Troubleshooting'],['P12','Pumps — Selection & Specs'],
    ['P13','Pumps — Site Setup'],['P14','Pumps — Reference Table'],['P15','Hydrant Setup'],
    ['P16','Hose & Fitting Reference'],['P17','Friction Loss'],['P18','Water Supply — Mass Water'],
    ['P19','Water Supply — Storage & Contractors'],['P20','Pumping Math'],['P21','Demob Checklist'],
  ],
  D:[
    ['D01','Defence Roles'],['D02','Task Force & Strike Team Setup'],['D03','Property Approach & Size-Up'],
    ['D04','Tactics: Anchor and Hold'],['D05','Tactics: Bump and Run'],['D06','Tactics: Fire Front Following'],
    ['D07','Tactics: Mobile Tactical Patrol'],['D08','Patrol & Mop-Up After Front Passage'],['D09','Weather Triggers'],
    ['D10','Night Operations'],['D11','Helicopters & Bucketing'],['D12','Heavy Equipment Near Structures'],
    ['D13','Suppression Integration'],['D14','ICS Org Chart — SD Operations'],['D15','TFL Demob Checklist'],
  ],
  S:[
    ['S01','LACES'],['S02','Watch-Outs'],['S03','Trigger Points'],['S04','Risk Management'],
    ['S05','Refusal of Risk'],['S06','Last Resort Survival'],['S07','Entrapment Protocols'],
    ['S08','Medical Emergency Response'],['S09','Heat Exposure'],['S10','Conversions'],['S11','Glossary'],
  ],
  O:[
    ['O01','STAM Role'],['O02','Staging Setup'],['O03','Documentation & Reporting'],['O04','Resource Tracking'],
  ],
};

// topics flagged as having complex infographics
const HAS_INFOGRAPHIC = new Set(['P04','P05','P14','P17','P20','D14','S01','S10']);

const CE_SESSIONS = [
  [1,'You Are the Field Safety Officer','May 6, 2026'],
  [2,'Communication and Information at the Branch Level','Apr 1, 2026'],
  [3,'WUI Fire Behaviour & Predictive Services for Leaders','Mar 18, 2026'],
  [4,'Night Ops','Mar 4, 2026'],
  [5,'Using Community Assessments','Feb 4, 2026'],
  [6,'Integrating Cultural and Prescribed Fire','Jan 14, 2026'],
  [7,"Trigger Points and the Safety Officer's Role",'Jan 7, 2026'],
  [8,'Coordinating Municipal Engines','Dec 3, 2025'],
  [9,'Survey 123','Nov 5, 2025'],
  [10,'SPS Training Plan Submission','Dec 2, 2025'],
  [11,'You Are the Branch','Nov 5, 2025'],
  [12,'BCWS Field Safety Officer Roles & Responsibilities',''],
  [13,'3rd Party Resources & Updates to the Interagency Agreement',''],
  [14,'Working with Local Nations and Third Party Resources',''],
  [15,'Structure Defense Planning',''],
  [16,'Danger Tree Assessing, Field Accountability & Finance',''],
  [17,'Avenza Mapping','Feb 27, 2025'],
  [18,'SRG Pathway & OSWS 2',''],
];

// ── Real content: P01 ───────────────────────────────────────────────────────
const CONTENT = {
  P01:{
    quickRef:[
      ['SPS lives under <b>Plans</b> in ICS','moves to Branch Director role once resources are assigned'],
      ['Certification path','Trainee → Qualified → Certified (BC Fire Line Cert Manual, 2025)'],
      ['12-step arrival process','dispatch contact → IC integration → environment typing → defendable / non-defendable → PACE planning → resource ordering'],
      ['Environment types','Interface / Intermix / Occluded — tactics differ for each'],
      ['Resource ratio','1:1 intermix · 1:3 interface (prep-and-defend)'],
      ['Flow calculation','500 GPM per Type 2 SPU'],
      ['Safety check-ins','4-hr intervals (moderate risk, &gt;5 persons) · 30-min (near-structure defence)'],
      ['SPS signs DTR','as BCWS financial representative — legal accountability'],
    ],
    doctrine:[
      ['First-in SPS ≠ Branch Director yet.','Do the work at smaller scale until resources arrive under you.'],
      ['PACE at SPS level covers the whole AOI','(protection + defence + large water). TFLs build their own tactical PACE inside yours.'],
      ['HFI (Head Fire Intensity) drives defendability','see the intensity ladder below.'],
      ['FNESS and WDS are present at many incidents','but not on the BCWS org chart. Deconfliction is your responsibility.'],
    ],
    quote:['Structure protection specialist lives under plans until you have resources under you — then you move into operations as structure branch director.','Brian Hutchinson'],
    hfi:[
      ['Knee height','Direct attack — hand tools / engines','#34D399'],
      ['Head height','Direct attack with water','#A3D139'],
      ['Engine height (~8 ft)','Limit of direct attack','#FFD23D'],
      ['Single storey','Indirect / structure defence only','#FF9F40'],
      ['Two storey +','Extreme — defensive actions unsafe','#FF5B52'],
    ],
  },
};

// ── CE detail (real titles + structured sample summary/takeaways) ────────────
function ceDetail(item){
  const [n,title,date]=item;
  return {
    n,title,date,
    runtime: 8 + ((n*7)%34),  // pseudo runtime mins
    summary:`Session summary for "${title}". Full written summary of the BCWS continuing-education session, captured for field reference. Replace with the finalized summary text.`,
    takeaways:[
      'Primary doctrine point or decision rule established in this session.',
      'Second key takeaway — what changes in the field as a result.',
      'A watch-out, common mistake, or coordination note raised by the presenter.',
    ],
    transcript:[
      `[00:00] Introduction — presenter sets context for "${title}".`,
      '[02:14] Core material walked through with field examples.',
      '[15:40] Q&A and discussion of edge cases.',
      '[ … ] Full transcript continues — drop the verbatim transcript here.',
    ],
  };
}

// ── Sample body generator for topics without finalized content ───────────────
function sampleContent(code,title){
  const t=title.replace(/^[A-Z]\d+\s*/,'');
  return {
    sample:true,
    quickRef:[
      [`Key reference for <b>${t}</b>`,'one-line field rule goes here'],
      ['Critical numbers / specs','the figures a crew needs at a glance'],
      ['Decision criteria','go / no-go thresholds for this topic'],
      ['Standard procedure','the abbreviated step sequence'],
    ],
    doctrine:[
      ['Why it matters','the reasoning behind the quick-reference rule.'],
      ['How it connects','where this fits in the broader protection / defence plan.'],
      ['Field considerations','what changes under pressure, fatigue, or poor conditions.'],
    ],
  };
}

function getContent(code,title){ return CONTENT[code] || sampleContent(code,title); }
function bookletOf(code){ return BOOKLETS.find(b=>b.id===code[0]); }
function titleOf(code){ const b=code[0]; const f=(TOPICS[b]||[]).find(t=>t[0]===code); return f?f[1]:code; }

Object.assign(window,{ BOOKLETS, TOPICS, CE_SESSIONS, CONTENT, HAS_INFOGRAPHIC,
  ceDetail, getContent, bookletOf, titleOf });
